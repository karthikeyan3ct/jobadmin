import React, { Component } from 'react';
import ReactDom from 'react-dom';

class FooterPage extends Component{
    render(){
        return(
<div>
<footer className="footer">
  <div className="container-fluid">
    <div className="row">
      <div className="col-12">
        © 2020 Macbro Technology
      </div>
    </div>
  </div>
</footer>

</div>
        )
    }
}


export default FooterPage;